//
//  TaskRowView.swift
//  TaskManager_L9
//
//  Created by ilyas uyanik on 3/23/25.
//

import SwiftUI

struct TaskRowView: View {
    let task: Task
    var onComplete: () -> Void
    var onDelete: () -> Void
    var onUndo: () -> Void
    
    @State private var showActionSheet = false
    @State private var showAlert = false
    
    var body: some View {
        HStack {
            Text(task.title)
                .strikethrough(task.isCompleted, color: .gray)
                .foregroundColor(task.isCompleted ? .gray : .primary)
            Spacer()
            
            Button( action: {
                showActionSheet = true
            }) {
                Image(systemName: "ellipsis.circle")
                    .foregroundColor(.blue)
            }
            .actionSheet(isPresented: $showActionSheet, content: {
                ActionSheet(title: Text("Task Options"), message: Text("Choose and Action"), buttons: actionButtons())
            })
        }
        .padding()
        .background(Color(UIColor.systemBackground))
        .cornerRadius(8)
        .shadow(radius: 1)
        .alert(isPresented: $showAlert, content: {
            Alert(title: Text("Delete Task"), message: Text("Are you sure you want to delete this task?"), primaryButton: .destructive(Text("Delete")) {
                onDelete()
            }, secondaryButton: .cancel())
        })
    }
    
    private func actionButtons() -> [ActionSheet.Button] {

        var buttons: [ActionSheet.Button] = []
        
        if task.isCompleted {
            buttons.append(.default(Text("Undo"), action: onUndo))
        } else {
            buttons.append(.default(Text("Complete"), action: onComplete))
        }
        
        buttons.append(.destructive(Text("Delete"), action: { showAlert = true }))
        
        return buttons
    }
}

//#Preview {
//    TaskRowView()
//}
