//
//  ContentView.swift
//  TaskManager_L9
//
//  Created by ilyas uyanik on 3/23/25.
//

import SwiftUI

struct TaskView: View {
    
    @StateObject var viewModel = TaskViewModel()
    
    var body: some View {
        NavigationView {
            List {
                ForEach(viewModel.tasks) { task in
                    TaskRowView(
                        task: task,
                        onComplete: {
                            viewModel.completeTask(task)
                        }, 
                        onDelete: { 
                            viewModel.deleteTask(task)
                        },
                        onUndo: {
                            viewModel.undoTask(task)
                    })
                }
            }
            .navigationTitle("Task Manager")
        }
        
        if let toastMessage = viewModel.toastMessage {
            VStack {
                Spacer()
                ToastView(message: toastMessage)
            }
            .transition(.move(edge: .bottom))
            .animation(.easeInOut, value: toastMessage)
        }
    }
}

#Preview {
    TaskView()
}
