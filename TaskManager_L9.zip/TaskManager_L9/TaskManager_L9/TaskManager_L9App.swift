//
//  TaskManager_L9App.swift
//  TaskManager_L9
//
//  Created by ilyas uyanik on 3/23/25.
//

import SwiftUI

@main
struct TaskManager_L9App: App {
    var body: some Scene {
        WindowGroup {
            TaskView()
        }
    }
}
