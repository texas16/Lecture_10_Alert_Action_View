//
//  ToastView.swift
//  TaskManager_L9
//
//  Created by ilyas uyanik on 3/23/25.
//

import SwiftUI

struct ToastView: View {
    let message: String
    var body: some View {
        Text(message)
            .padding()
            .background(Color.black.opacity(0.7))
            .foregroundColor(.white)
            .cornerRadius(10)
            .padding(.bottom, 20)
        
    }
}

//#Preview {
//    ToastView()
//}
