//
//  Task.swift
//  TaskManager_L9
//
//  Created by ilyas uyanik on 3/23/25.
//

import Foundation

struct Task : Identifiable {
    let id = UUID()
    var title: String
    var isCompleted: Bool
}
