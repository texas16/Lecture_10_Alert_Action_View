//
//  TaskViewModel.swift
//  TaskManager_L9
//
//  Created by ilyas uyanik on 3/23/25.
//

import Foundation

class TaskViewModel : ObservableObject {
    
    @Published var tasks: [Task] = [
        Task(title: "Finish Swift Project", isCompleted: false),
        Task(title: "Finish Object Oriented Assignment", isCompleted: false),
        Task(title: "Complete Secret Project", isCompleted: false),
    ]
    
    @Published var toastMessage: String? = nil
    
    func completeTask(_ task: Task) {
        if let index = tasks.firstIndex(where: {$0.id == task.id }) {
            tasks[index].isCompleted = true
            showToast(message: "Task marked as completed!")
        }
    }
    
    func deleteTask(_ task: Task) {
        tasks.removeAll {$0.id == task.id}
        showToast(message: "Task deleted!")
    }
    
    func undoTask(_ task: Task) {
        if let index = tasks.firstIndex(where: {$0.id == task.id }) {
            tasks[index].isCompleted = false
            showToast(message: "Task restored!")
        }
    }
    
    private func showToast(message: String) {
        toastMessage = message
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            self.toastMessage = nil
        }
    }
}
