//
//  MultipleActionsAlertView.swift
//  Alert_Toast_L9
//
//  Created by ilyas uyanik on 3/23/25.
//

import SwiftUI

struct MultipleActionsAlertView: View {
    @State private var showAlert = false
    
    var body: some View {
        Button("Delete Item") {
            showAlert = true
        }
        .alert("Delete", isPresented: $showAlert) {
            // role: cancel - provides safe exist from the alert
            Button("Cancel", role: .cancel) {}
            // " role: destructive - make button to be appear in red
            Button("Delete", role: .destructive) { delete()}
        } message: {
            Text("Are you sure you want to delete this item?")
        }
    }
    
    private func delete()  {
        // do whatever logic that want to implement here
    }
}

#Preview {
    MultipleActionsAlertView()
}
