//
//  ToastView.swift
//  Alert_Toast_L9
//
//  Created by ilyas uyanik on 3/23/25.
//

import SwiftUI

struct ToastView: View {
    @State private var showToast = false
    var body: some View {
        VStack {
            Button("Show Toast") {
                withAnimation {
                   showToast = true
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    withAnimation {
                        showToast = false
                    }
                }
            }
            
            if showToast {
                Text("Item added to cart!")
                    .padding()
                    .background(Color.black.opacity(1))
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .transition(.slide)
                    .padding(.top, 50)
            }
        }
    }
}

#Preview {
    ToastView()
}
