//
//  SimpleAlertView.swift
//  Alert_Toast_L9
//
//  Created by ilyas uyanik on 3/23/25.
//

import SwiftUI

struct SimpleAlertView: View {
    @State private var showAlert = false
    
    var body: some View {
        Button("Show Alert") {
            showAlert = true
        }
        .alert("Important Notice", isPresented: $showAlert) {
            Button("OK", role: .cancel) {
                // if there is a need, then call a method
            }
        } message: {
            Text("Your changes have been saved successfully!")
        }
    }
}

#Preview {
    SimpleAlertView()
}
