//
//  ActionSheetView.swift
//  Alert_Toast_L9
//
//  Created by ilyas uyanik on 3/23/25.
//

import SwiftUI

struct ActionSheetView: View {
    @State private var showSheet = false
    
    var body: some View {
        Button("Show Action Sheet") {
            showSheet = true
        }
        .actionSheet(isPresented: $showSheet, content: {
            ActionSheet(title: Text("Select Option"), message: Text("Choose your action"),
                buttons:[
                      .default(Text("Save")) {print("Saved")},
                      .destructive(Text("Delete")) { print("Deleted")}
                ]
            )
        })
    }
}

#Preview {
    ActionSheetView()
}
